//
//  fifthViewController.swift
//  meatshop
//
//  Created by irohub on 20/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit
import SideMenu

class fifthViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var imgvw: UIImageView!
    let arr=["Login","All Products","Refer & Earn","Offers","Recipes","Edit Profile","About","Contact"]
    let ig=["login","products","refer","offers","recipes","faq","aboutus","contactus"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cv=tableView.dequeueReusableCell(withIdentifier: "cel")as! newTableViewCell
        cv.lb.text=arr[indexPath.row]
        cv.im.image=UIImage(named: ig[indexPath.row])
        return cv
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 42
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row==4{
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "seven")as! seventhViewController
        self.navigationController?.pushViewController(nw, animated: true)
        }
        else if indexPath.row==5{
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "nine")as! ninethViewController
        self.navigationController?.pushViewController(nw, animated: true)
        }
        else if indexPath.row==6{
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "ten")as! tenthViewController
        self.navigationController?.pushViewController(nw, animated: true)
        }
        else if indexPath.row==0{
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "one")as! ViewController
        self.navigationController?.pushViewController(nw, animated: true)
        }
        else if indexPath.row==1{
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "four")as! fouthViewController
        self.navigationController?.pushViewController(nw, animated: true)
        }
}
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
