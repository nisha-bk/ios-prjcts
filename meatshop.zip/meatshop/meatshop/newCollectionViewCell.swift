//
//  newCollectionViewCell.swift
//  meatshop
//
//  Created by irohub on 26/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class newCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
}
