//
//  fouthViewController.swift
//  meatshop
//
//  Created by irohub on 20/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class fouthViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
    @IBOutlet weak var cv: UICollectionView!
    var dict=NSDictionary()
    var getdata=NSMutableData()
    var arr=NSArray()
    var userid=UserDefaults.standard.string(forKey: "user-id")
    var a=""
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cv=collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath)as! new2CollectionViewCell
            self.dict=self.arr[indexPath.row]as! NSDictionary
            cv.lb.text=self.dict["name"]as? String
            cv.lb1.text=self.dict["price"]as? String
            let imgurl=String(describing: self.dict["image"]!)
            let urlimg=URL(string:imgurl)
            let dtimg=try?Data(contentsOf: urlimg!)
            cv.imgvw.image=UIImage(data: dtimg!)
            return cv
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.dict=self.arr[indexPath.row]as! NSDictionary
        let lc=self.dict["product_id"]as? String
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "six")as! sixthViewController
        self.navigationController?.pushViewController(nw, animated: true)
        nw.b=lc!
    }

    

    override func viewDidLoad() {
        let url1 = URL(string:"https://iroidtechnologies.in/MeatShop/index.php?route=api/completeapi/categoryProducts&api_token=")
        var req=URLRequest(url: url1!)
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField:"content_type")
        req.httpMethod="post"
        let poststr="category_id=\(a)&user_id=\(userid!)&key=\("koFCpCMzm8hhn9ULj0BnUzZkpqM3rg9Mqdii3FwPRjBwZFQWriIJYgB5jjOhNIyasSl4RrmCFLW3tHDRtI39viQbYEP7nEkYvba2wstThYWjvkndZq0zaXJaWjuqeZo8vR3MMHa6OhBDKsFPmWOlIM4H1TgB1fudQndGKzUPg8YhAoaAoCxZ562zjbQdPO73ZkwyPV7iOIkyH11ZLAN42a5dgLH22Rs1VasEWBKdfkqMLPfDbLQpF9Ofqah4fqwc")"
        print("poststring",poststr)
        req.httpBody=poststr.data(using: .utf8)
        let task=URLSession.shared.dataTask(with: req){(data,response,error)in
        let mydata=data
            do{
                print("mydata",mydata!)
                do{
                self.getdata.append(mydata!)
                let jsdata:NSDictionary=try JSONSerialization.jsonObject(with: self.getdata as Data, options: []) as! NSDictionary
                print("jsdata",jsdata)
                    self.arr=jsdata["data"]as! NSArray
                    DispatchQueue.main.sync {
                self.cv.reloadData()
              }
            }
            catch{
                print("error",error.localizedDescription)
            }
            }
            
        }
        task.resume()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func bck(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
