//
//  new3CollectionViewCell.swift
//  meatshop
//
//  Created by irohub on 26/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class new3CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var igg: UIImageView!
    @IBOutlet weak var lb1: UILabel!
    
    @IBOutlet weak var imgvw: UIImageView!
    @IBOutlet weak var lb2: UILabel!
}
