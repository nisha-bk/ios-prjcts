//
//  newTableViewCell.swift
//  meatshop
//
//  Created by iroid on 7/5/1402 AP.
//  Copyright © 1402 irohub. All rights reserved.
//

import UIKit

class newTableViewCell: UITableViewCell {

    @IBOutlet weak var lb: UILabel!
    @IBOutlet weak var im: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
