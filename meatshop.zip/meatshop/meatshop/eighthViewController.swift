//
//  eighthViewController.swift
//  meatshop
//
//  Created by irohub on 21/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class eighthViewController: UIViewController {

    @IBOutlet weak var vw: UIView!
    @IBOutlet weak var tv1: UITextView!
    @IBOutlet weak var tv: UITextView!
    @IBOutlet weak var call: UILabel!
    @IBOutlet weak var tim: UILabel!
    @IBOutlet weak var tit: UILabel!
    @IBOutlet weak var img: UIImageView!
    var c=""
    @IBOutlet weak var main: UILabel!
    var dt=NSDictionary()
    var rep=NSDictionary()
    var getdata=NSMutableData()
    var userid=UserDefaults.standard.string(forKey: "user-id")
    override func viewDidLoad() {
        let url1 = URL(string:"https://iroidtechnologies.in/MeatShop/index.php?route=api/completeapi/recipe&api_token")
        var req=URLRequest(url: url1!)
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField:"content_type")
        req.httpMethod="post"
        let poststr="recipe_id=\(c)&user_id=\(userid!)&key=\("koFCpCMzm8hhn9ULj0BnUzZkpqM3rg9Mqdii3FwPRjBwZFQWriIJYgB5jjOhNIyasSl4RrmCFLW3tHDRtI39viQbYEP7nEkYvba2wstThYWjvkndZq0zaXJaWjuqeZo8vR3MMHa6OhBDKsFPmWOlIM4H1TgB1fudQndGKzUPg8YhAoaAoCxZ562zjbQdPO73ZkwyPV7iOIkyH11ZLAN42a5dgLH22Rs1VasEWBKdfkqMLPfDbLQpF9Ofqah4fqwc")"
        print("poststring",poststr)
        req.httpBody=poststr.data(using: .utf8)
        let task=URLSession.shared.dataTask(with: req){(data,response,error)in
        let mydata=data
            do{
                print("mydata",mydata!)
                do{
                self.getdata.append(mydata!)
                let jsdata:NSDictionary=try JSONSerialization.jsonObject(with: self.getdata as Data, options: []) as! NSDictionary
                print("jsdata",jsdata)
                    DispatchQueue.main.sync {
                self.dt=jsdata["data"]as! NSDictionary
                self.rep=self.dt["recipie"]as! NSDictionary
                self.tit.text=self.rep["name"]as? String
                self.main.text=self.rep["name"]as? String
                self.tim.text=self.rep["time"]as? String
                self.call.text=self.rep["cals"]as? String
                self.tv1.text=self.rep["description"]as? String
                self.tv.text=self.rep["ingredients"]as? String
                let imgurl=String(describing:self.rep["image"]!)
                let urlimg=URL(string: imgurl)
                let dtimg=try?Data(contentsOf: urlimg!)
                self.img.image=UIImage(data: dtimg!)
            }
                }   catch{
                        print("error")
                    }
                }
            }
        task.resume()
        super.viewDidLoad()
 initialSetup()
        // Do any additional setup after loading the view.
    }
    func initialSetup() {
    vw.backgroundColor = .clear
    let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.clear,UIColor.gray, UIColor.black.cgColor]
        gradientLayer.frame=vw.bounds
    vw.layer.insertSublayer(gradientLayer, at: 1)
        
    }

    @IBAction func bck(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
