//
//  ViewController.swift
//  meatshop
//
//  Created by irohub on 18/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var bts: UIButton!
    @IBOutlet weak var tf1: UITextField!
    @IBOutlet weak var tf: UITextField!
    @IBOutlet weak var vw: UIView!
    @IBOutlet weak var btn: UIButton!
    var getdata=NSMutableData()
    var iconClick=true
    override func viewDidLoad() {
        btn.layer.cornerRadius=20
        btn.layer.borderWidth=1
        vw.layer.cornerRadius=10
        vw.layer.shadowColor=UIColor.lightGray.cgColor
        vw.layer.shadowOpacity=0.5
        vw.layer.shadowOffset=CGSize.zero
        vw.layer.shadowRadius=6
        
        self.tf.setUnderLine()
          //    tf.clipsToBounds=true
        self.tf1.setUnderLine()
           //   tf1.clipsToBounds=true
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func sign(_ sender: Any) {
        let ms=UIStoryboard(name: "Main", bundle: nil)
        let nw=ms.instantiateViewController(identifier: "sec")as! secViewController
        self.navigationController?.pushViewController(nw, animated: true)
    }
    
    @IBAction func login(_ sender: Any) {
    let url1=URL(string: "https://iroidtechnologies.in/MeatShop/index.php?route=api/login&api_token=")
    var req=URLRequest(url: url1!)
    req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField:"content_type")
    req.httpMethod="post"
    let poststr="email=\(tf.text!)&password=\(tf1.text!)&key=\("koFCpCMzm8hhn9ULj0BnUzZkpqM3rg9Mqdii3FwPRjBwZFQWriIJYgB5jjOhNIyasSl4RrmCFLW3tHDRtI39viQbYEP7nEkYvba2wstThYWjvkndZq0zaXJaWjuqeZo8vR3MMHa6OhBDKsFPmWOlIM4H1TgB1fudQndGKzUPg8YhAoaAoCxZ562zjbQdPO73ZkwyPV7iOIkyH11ZLAN42a5dgLH22Rs1VasEWBKdfkqMLPfDbLQpF9Ofqah4fqwc")"
    print("poststring",poststr)
    req.httpBody=poststr.data(using: .utf8)
    let task=URLSession.shared.dataTask(with: req){(data,response,error)in
    let mydata=data
        do{
            print("mydata",mydata!)
            do{
                self.getdata.append(mydata!)
                let jsdata:NSDictionary=try JSONSerialization.jsonObject(with: self.getdata as Data, options: []) as! NSDictionary
                print("jsdata",jsdata)
                DispatchQueue.main.sync {
                    if self.tf.text==""||self.tf1.text==""{
                    let ac=UIAlertController(title: "Message", message: "Your textfields are empty", preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
                        }
                    ac.addAction(OKAction)
                    self.present(ac, animated: true, completion: nil)
                        return
                    }
                    else{
                    
                UserDefaults.standard.set(jsdata["user_id"], forKey: "user-id")
                    if jsdata["message"]as? String=="successfuly logged"{
                        
                    let ms=UIStoryboard(name: "Main", bundle: nil)
                    let nw=ms.instantiateViewController(identifier: "fourr")as! fourthViewController
                    self.navigationController?.pushViewController(nw, animated: true)
                    }
                    else if jsdata["message"]as? String=="Invalid username or password"{
                    let ac=UIAlertController(title: "Message", message: "invalid username or password", preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
                        }
                        ac.addAction(OKAction)
                        self.present(ac, animated: true, completion: nil)
                        return
                        
                    }
                    }
               
                        }
            }
        }
       catch{
                print("error",error.localizedDescription)
            }
            
        }
        task.resume()
            }
    
    @IBAction func bn(_ sender: Any) {
        if iconClick {

            tf1.isSecureTextEntry = false

        bts.setImage(UIImage(named: "password"), for: .normal)

        } else {

            tf1.isSecureTextEntry = true

            bts.setImage(UIImage(named: "hidepassword"), for: .normal)

        }

        iconClick = !iconClick
    }
}

extension UITextField {

func setUnderLine() {
        let border = CALayer()
        border.backgroundColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - 1, width:self.frame.size.width, height: 2)
        self.layer.addSublayer(border)
    }

}

