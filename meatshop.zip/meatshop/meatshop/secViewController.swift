//
//  secViewController.swift
//  meatshop
//
//  Created by irohub on 19/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class secViewController: UIViewController {

    @IBOutlet weak var tf4: UITextField!
    @IBOutlet weak var tf5: UITextField!
    @IBOutlet weak var tf3: UITextField!
    @IBOutlet weak var tf: UITextField!
    @IBOutlet weak var tf2: UITextField!
    @IBOutlet weak var tf1: UITextField!
    var getdata=NSMutableData()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
        self.tf.setUnderLine()
        self.tf1.setUnderLine()
        self.tf2.setUnderLine()
        self.tf3.setUnderLine()
        self.tf4.setUnderLine()
        self.tf5.setUnderLine()
       }

    
    @IBAction func bck(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func reg(_ sender: Any) {
        let url1=URL(string: "https://iroidtechnologies.in/MeatShop/index.php?route=api/register&api_token=")
        var req=URLRequest(url: url1!)
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField:"content_type")
        req.httpMethod="post"
        let poststr="firstname=\(tf.text!)&lastname=\(tf1.text!)&email=\(tf2.text!)&telephone=\(tf3.text!)&password=\(tf4.text!)&type=\("0")&referal_code=\("0")&key=\("koFCpCMzm8hhn9ULj0BnUzZkpqM3rg9Mqdii3FwPRjBwZFQWriIJYgB5jjOhNIyasSl4RrmCFLW3tHDRtI39viQbYEP7nEkYvba2wstThYWjvkndZq0zaXJaWjuqeZo8vR3MMHa6OhBDKsFPmWOlIM4H1TgB1fudQndGKzUPg8YhAoaAoCxZ562zjbQdPO73ZkwyPV7iOIkyH11ZLAN42a5dgLH22Rs1VasEWBKdfkqMLPfDbLQpF9Ofqah4fqwc")"
        print("poststring",poststr)
        req.httpBody=poststr.data(using: .utf8)
        let task=URLSession.shared.dataTask(with: req){(data,response,error)in
            let mydata=data
            do{
                print("mydata",mydata!)
                do{
                    self.getdata.append(mydata!)
                     let jsdata:NSDictionary=try JSONSerialization.jsonObject(with: self.getdata as Data, options: []) as! NSDictionary
                    print("jsdata",jsdata)
                    DispatchQueue.main.sync {
                    if self.tf.text==""||self.tf1.text==""||self.tf2.text==""||self.tf3.text==""||self.tf4.text==""||self.tf5.text==""{
                    let ac=UIAlertController(title: "Message", message: "Your textfields are empty", preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
                        }
                    ac.addAction(OKAction)
                    self.present(ac, animated: true, completion: nil)
                        return
                    }
                    else{
                    if jsdata["message"]as? String=="successfuly logged"{
                    let ms=UIStoryboard(name: "Main", bundle: nil)
                    let nw=ms.instantiateViewController(identifier: "fourr")as! fourthViewController
                    self.navigationController?.pushViewController(nw, animated: true)
                let ac=UIAlertController(title: "Message", message: "Registered successfully", preferredStyle: .alert)
                let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
                               }
                            ac.addAction(OKAction)
                            self.present(ac, animated: true, completion: nil)
                            return
                    }
                    else if jsdata["message"]as? String=="Warning: E-Mail Address is already registered!"{
                    let ac=UIAlertController(title: "Message", message: "invalid username or password", preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
                                           }
                        ac.addAction(OKAction)

                        
                        
          }
                }
                    }
            }
            catch{
                print("error",error.localizedDescription)
            }
            
        }
        }
        task.resume()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

