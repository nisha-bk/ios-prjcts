//
//  new1CollectionViewCell.swift
//  meatshop
//
//  Created by irohub on 26/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class new1CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgvw: UIImageView!
    @IBOutlet weak var lb: UILabel!
}
