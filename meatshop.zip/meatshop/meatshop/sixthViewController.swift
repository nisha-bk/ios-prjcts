//
//  sixthViewController.swift
//  meatshop
//
//  Created by irohub on 20/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class sixthViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate{
    @IBOutlet weak var cv: UICollectionView!
    var getdata=NSMutableData()
    var dt=NSDictionary()
    var arr=NSArray()
    var b=""
    var userid=UserDefaults.standard.string(forKey: "user-id")
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cv=collectionView.dequeueReusableCell(withReuseIdentifier: "cell3", for: indexPath)as! new3CollectionViewCell
    return cv
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    

    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var sub: UILabel!
    @IBOutlet weak var tit: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lb: UILabel!
    @IBOutlet weak var tv: UITextView!
    @IBOutlet weak var plu2: UIButton!
    @IBOutlet weak var min1: UIButton!
    @IBOutlet weak var plu: UIButton!
    @IBOutlet weak var min: UIButton!
    override func viewDidLoad() {
        plu.layer.cornerRadius=0.5*plu.bounds.size.width
        plu2.layer.cornerRadius=0.5*plu2.bounds.size.width
        min.layer.cornerRadius=0.5*min.bounds.size.width
        min1.layer.cornerRadius=0.5*min1.bounds.size.width

        let url1 = URL(string:"https://iroidtechnologies.in/MeatShop/index.php?route=api/completeapi/getProduct&api_token=")
        var req=URLRequest(url: url1!)
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField:"content_type")
        req.httpMethod="post"
        let poststr="product_id=\(b)&user_id=\(userid!)&key=\("koFCpCMzm8hhn9ULj0BnUzZkpqM3rg9Mqdii3FwPRjBwZFQWriIJYgB5jjOhNIyasSl4RrmCFLW3tHDRtI39viQbYEP7nEkYvba2wstThYWjvkndZq0zaXJaWjuqeZo8vR3MMHa6OhBDKsFPmWOlIM4H1TgB1fudQndGKzUPg8YhAoaAoCxZ562zjbQdPO73ZkwyPV7iOIkyH11ZLAN42a5dgLH22Rs1VasEWBKdfkqMLPfDbLQpF9Ofqah4fqwc")"
        print("poststring",poststr)
        req.httpBody=poststr.data(using: .utf8)
        let task=URLSession.shared.dataTask(with: req){(data,response,error)in
        let mydata=data
            do{
                print("mydata",mydata!)
                do{
                self.getdata.append(mydata!)
                let jsdata:NSDictionary=try JSONSerialization.jsonObject(with: self.getdata as Data, options: []) as! NSDictionary
                print("jsdata",jsdata)
                    DispatchQueue.main.sync {
                self.dt=jsdata["data"]as! NSDictionary
                self.tit.text=self.dt["name"]as? String
                self.sub.text=self.dt["name"]as? String
                self.price.text=self.dt["whole_price"]as? String
                self.lb.text=self.dt["product_price"]as? String
                self.tv.text=self.dt["description"]as? String
                        let imgarr=self.dt["images"]as! NSArray
                        let imgurl=String(describing: imgarr[0])
                let urlimg=URL(string: imgurl)
                let dtimg=try?Data(contentsOf: urlimg!)
                self.img.image=UIImage(data: dtimg!)
            }
                }   catch{
                        print("error")
                    }
                }
            }
        task.resume()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func bck(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
