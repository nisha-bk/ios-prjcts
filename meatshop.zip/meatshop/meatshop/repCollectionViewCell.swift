//
//  repCollectionViewCell.swift
//  meatshop
//
//  Created by irohub on 27/09/23.
//  Copyright © 2023 irohub. All rights reserved.
//

import UIKit

class repCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lb3: UILabel!
    @IBOutlet weak var lb2: UILabel!
    @IBOutlet weak var lb1: UILabel!
    @IBOutlet weak var img: UIImageView!
}
