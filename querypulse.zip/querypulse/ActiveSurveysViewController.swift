import UIKit
import CoreData

class ActiveSurveysViewController: UIViewController {

    @IBOutlet weak var surveysTableView: UITableView!
    var activeSurveys: [Survey] = [] // Core Data Survey objects

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupGradientBackground()
        
        self.navigationItem.title = "Active Surveys"
        surveysTableView.delegate = self
        surveysTableView.dataSource = self
        
        fetchActiveSurveys() // Fetch active surveys
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    // Fetch active surveys (isCompleted == false)
    private func fetchActiveSurveys() {
        let fetchRequest: NSFetchRequest<Survey> = Survey.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "isCompleted == %@", NSNumber(value: false))
        
        do {
            let fetchedSurveys = try PersistenceController.shared.container.viewContext.fetch(fetchRequest)
            self.activeSurveys = fetchedSurveys
            surveysTableView.reloadData()
        } catch {
            print("Failed to fetch active surveys: \(error)")
        }
    }

    @IBAction func backButtonTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension ActiveSurveysViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return activeSurveys.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "surveycell", for: indexPath)
        cell.textLabel?.text = activeSurveys[indexPath.row].title
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedSurvey = activeSurveys[indexPath.row]
        markSurveyAsCompleted(survey: selectedSurvey)
    }
    
    // Mark a survey as completed and save to Core Data
    private func markSurveyAsCompleted(survey: Survey) {
        survey.isCompleted = true
        survey.dateCompleted = Date()
        
        PersistenceController.shared.saveContext() // Save the context
        fetchActiveSurveys() // Refresh the list
    }
}
