import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var dashbutton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var resultsButton: UIButton!
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var categoriesButton: UIButton!
    @IBOutlet weak var surveyButton: UIButton!

    var surveyCompletionProgress: Float = 0.5
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()

        setupGradientBackground()
 
        setupGradientForButton(dashbutton)
        setupGradientForButton(surveyButton)
        setupGradientForButton(categoriesButton)
        setupGradientForButton(resultsButton)
        setupGradientForButton(profileButton)
        setupGradientForButton(logoutButton)

        progressBar.progress = surveyCompletionProgress
    }

    private func setupUI() {
        self.navigationItem.hidesBackButton = true

        logoutButton.layer.cornerRadius = 8.0
        logoutButton.clipsToBounds = true

        progressBar.tintColor = UIColor.systemBlue
        progressBar.trackTintColor = UIColor.systemGray
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    private func setupGradientForButton(_ button: UIButton) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemBlue.cgColor, UIColor.systemGreen.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = button.bounds
        
        button.layer.cornerRadius = button.frame.height / 2
        button.clipsToBounds = true
        button.layer.insertSublayer(gradientLayer, at: 0)

        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 3)
        button.layer.shadowOpacity = 0.2
        button.layer.shadowRadius = 4.0
    }

    @IBAction func goToDashboard(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if let dashboardVC = storyboard.instantiateViewController(withIdentifier: "dashboard") as? DashboardViewController {
                    self.navigationController?.pushViewController(dashboardVC, animated: true)
                }
    }

    @IBAction func startSurveyButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let surveyVC = storyboard.instantiateViewController(withIdentifier: "survey") as? SurveyDetailViewController {
            self.navigationController?.pushViewController(surveyVC, animated: true)
        }
    }

    @IBAction func categoriesButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let categoriesVC = storyboard.instantiateViewController(withIdentifier: "cat") as? CategoriesViewController {
            self.navigationController?.pushViewController(categoriesVC, animated: true)
        }
    }

    @IBAction func resultsButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let resultsVC = storyboard.instantiateViewController(withIdentifier: "results") as? ResultsViewController {
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }
    }
    
    @IBAction func profileButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let profileVC = storyboard.instantiateViewController(withIdentifier: "pro") as? ProfileViewController {
            self.navigationController?.pushViewController(profileVC, animated: true)
        }
    }

    @IBAction func logoutButtonTapped(_ sender: UIButton) {
        print("Logging out...")
 
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let loginVC = storyboard.instantiateViewController(withIdentifier: "login") as? loginViewController {
            self.navigationController?.setViewControllers([loginVC], animated: true)
        }
    }
}
