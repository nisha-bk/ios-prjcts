
import UIKit
import CoreData
import KeychainSwift

class signupViewController: UIViewController {

    @IBOutlet weak var rgbtn: UIButton!
    @IBOutlet weak var signupvw: UIView!
    @IBOutlet weak var crfmtf: UITextField!
    @IBOutlet weak var passtf: UITextField!
    @IBOutlet weak var emailtf: UITextField!

    let keychain = KeychainSwift()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupGradientBackground()

        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = signupvw.bounds
        signupvw.layer.insertSublayer(gradientLayer, at: 0)
        signupvw.layer.cornerRadius = 10.0
        signupvw.layer.borderColor = UIColor.systemPurple.cgColor
        signupvw.layer.borderWidth = 2.0
        signupvw.layer.shadowColor = UIColor.black.cgColor
        signupvw.layer.shadowOpacity = 0.2
        signupvw.layer.shadowOffset = CGSize(width: 0, height: 4)
        signupvw.layer.shadowRadius = 6.0

        rgbtn.layer.cornerRadius = rgbtn.frame.height / 2
        rgbtn.clipsToBounds = true

        // Round text fields
        roundTextField(crfmtf)
        roundTextField(passtf)
        roundTextField(emailtf)
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    func roundTextField(_ textField: UITextField) {
        textField.layer.cornerRadius = 5.0
        textField.layer.borderWidth = 1.0
        textField.layer.borderColor = UIColor.systemPurple.cgColor
        textField.clipsToBounds = true
        textField.setLeftPaddingPoints(10)
    }

    @IBAction func regbtn(_ sender: Any) {
        if let email = emailtf.text, let password = passtf.text, let confirmPassword = crfmtf.text {
            if email.isEmpty || password.isEmpty || confirmPassword.isEmpty {
                showAlert(message: "Please fill in all fields.")
            } else if !isValidEmail(email) {
                showAlert(message: "Please enter a valid email address.")
            } else if !isValidPassword(password) {
                showAlert(message: "Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one number.")
            } else if password != confirmPassword {
                showAlert(message: "Passwords do not match.")
            } else {
                saveUserDataToKeychain(email: email, password: password)
                saveUserDataToCoreData(email: email, password: password)
            }
        }
    }

    func saveUserDataToKeychain(email: String, password: String) {
        keychain.set(email, forKey: "userEmail")
        keychain.set(password, forKey: "userPassword")
    }

    func saveUserDataToCoreData(email: String, password: String) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

        // Create a new User object
        let newUser = User(context: context)
        newUser.email = email
        newUser.password = password

        // Save the context (this saves the User object to Core Data)
        do {
            try context.save()
            showAlert(message: "Registration successful!")
            
            let ms = UIStoryboard(name: "Main", bundle: nil)
            if let loginVC = ms.instantiateViewController(withIdentifier: "login") as? loginViewController {

                if let navigationController = self.navigationController {
                    navigationController.pushViewController(loginVC, animated: true)
                } else {
                    self.present(loginVC, animated: true, completion: nil)
                }}}catch {
            print("Failed to save user in Core Data: \(error)")
            showAlert(message: "An error occurred while saving your data.")
        }
    }

    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: email)
    }

    func isValidPassword(_ password: String) -> Bool {
        let passwordRegex = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d).{8,}$" // Regex for password validation
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
        return passwordTest.evaluate(with: password)
    }

    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

}
