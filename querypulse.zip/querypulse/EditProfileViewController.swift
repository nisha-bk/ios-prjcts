import UIKit
import CoreData

class EditProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    var user: User?  // This will hold the current user's data from Core Data
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupGradientBackground()
        loadUserData()
        
        saveButton.layer.cornerRadius = 5.0
        saveButton.clipsToBounds = true
    }
    
    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    private func loadUserData() {
        // If user is available, populate the fields with their current data
        if let user = user {
            nameTextField.text = user.name
            emailTextField.text = user.email
            passwordTextField.text = user.password
        }
        
        
        func saveButtonTapped(_ sender: UIButton) {
            guard let name = nameTextField.text, !name.isEmpty else {
                showAlert(message: "Please enter your name.")
                return
            }
            
            guard let email = emailTextField.text, !email.isEmpty else {
                showAlert(message: "Please enter your email.")
                return
            }
            
            guard isValidEmail(email) else {
                showAlert(message: "Please enter a valid email address.")
                return
            }
            
            guard let password = passwordTextField.text, !password.isEmpty else {
                showAlert(message: "Please enter a password.")
                return
            }
            
            // Save the updated user data
            saveUserData(name: name, email: email, password: password)
            
            showAlert(message: "Your profile has been updated successfully!")
        }
        
      func isValidEmail(_ email: String) -> Bool {
            let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,}"
            let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
            return emailTest.evaluate(with: email)
        }
        
       func showAlert(message: String) {
            let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
        
        func saveUserData(name: String, email: String, password: String) {
            guard let user = user else { return }
            
            // Get the context from AppDelegate
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            user.name = name
            user.email = email
            user.password = password
            
            // Save the context
            do {
                try context.save()
            } catch {
                print("Failed to save user data: \(error)")
                showAlert(message: "Failed to save changes. Please try again.")
            }
        }
    }
}
