import UIKit
import CoreData

class CategoriesViewController: UIViewController {

    @IBOutlet weak var categoriesTableView: UITableView!
    var categories: [Cat] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up gradient background
        setupGradientBackground()

        // Set up table view
        self.navigationItem.title = "Survey Categories"
        categoriesTableView.delegate = self
        categoriesTableView.dataSource = self

        // Fetch categories from Core Data
        fetchCategories()
        categoriesTableView.reloadData()
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    // Fetch categories from Core Data
    private func fetchCategories() {
        let fetchRequest: NSFetchRequest<Cat> = Cat.fetchRequest()

        do {
            let fetchedCategories = try PersistenceController.shared.container.viewContext.fetch(fetchRequest)
            self.categories = fetchedCategories
        } catch {
            print("Failed to fetch categories: \(error)")
        }
    }

    // Example of adding a new category
    private func addNewCategory(title: String, isSelected: Bool) {
        let context = PersistenceController.shared.container.viewContext

        // Create a new Categories entity
        let newCategory = Cat(context: context)
        newCategory.title = title
        newCategory.isSelected = isSelected

        // Save context
        PersistenceController.shared.saveContext()

        // Fetch the updated categories
        fetchCategories()
        categoriesTableView.reloadData()
    }

    @IBAction func backButtonTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension CategoriesViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell", for: indexPath)
        let category = categories[indexPath.row]

        // Set the title of the category
        cell.textLabel?.text = category.title

        // Optionally, you can configure a checkmark or other UI for isSelected
        if category.isSelected {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let category = categories[indexPath.row]

        // Toggle the isSelected property
        category.isSelected.toggle()

        // Save the context to update Core Data
        PersistenceController.shared.saveContext()

        // Reload table view to reflect the changes
        categoriesTableView.reloadData()

        print("Selected category: \(category.title ?? "")")
    }
}
