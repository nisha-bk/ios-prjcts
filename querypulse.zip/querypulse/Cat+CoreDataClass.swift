//
//  Cat+CoreDataClass.swift
//  
//
//  Created by Allnet Systems on 3/25/25.
//
//

import Foundation
import CoreData

@objc(Cat)
public class Cat: NSManagedObject {

}
