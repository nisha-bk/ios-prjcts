import UIKit
import CoreData

class CompletedSurveysViewController: UIViewController {

    @IBOutlet weak var surveysTableView: UITableView!
    var completedSurveys: [Survey] = [] // Core Data Survey objects

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupGradientBackground()
        
        self.navigationItem.title = "Completed Surveys"
        surveysTableView.delegate = self
        surveysTableView.dataSource = self
        
        fetchCompletedSurveys() // Fetch completed surveys
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    // Fetch completed surveys (isCompleted == true)
    private func fetchCompletedSurveys() {
        let fetchRequest: NSFetchRequest<Survey> = Survey.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "isCompleted == %@", NSNumber(value: true))
        
        do {
            let fetchedSurveys = try PersistenceController.shared.container.viewContext.fetch(fetchRequest)
            self.completedSurveys = fetchedSurveys
            surveysTableView.reloadData()
        } catch {
            print("Failed to fetch completed surveys: \(error)")
        }
    }

    @IBAction func backButtonTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension CompletedSurveysViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return completedSurveys.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "comcell", for: indexPath)
        cell.textLabel?.text = completedSurveys[indexPath.row].title
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Selected completed survey: \(completedSurveys[indexPath.row].title ?? "No Title")")
    }
}
