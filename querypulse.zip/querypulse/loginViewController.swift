import UIKit
import CoreData

class loginViewController: UIViewController {
    
    @IBOutlet weak var lgnvw: UIView!
    @IBOutlet weak var logoimg: UIImageView!
    @IBOutlet weak var lgnbtn: UIButton!
    @IBOutlet weak var passimg: UIImageView!
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var showPasswordButton: UIButton!
    
    var isPasswordVisible = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        setupGradientBackground()
        highlightLoginView()
        pass.isSecureTextEntry = true
        setupTextFieldStyles()
        updatePasswordVisibilityIcon()
        
        lgnbtn.layer.cornerRadius = lgnbtn.frame.height / 2
        lgnbtn.clipsToBounds = true
    }
    
    @IBAction func forgetpass(_ sender: Any) {
        let alertController = UIAlertController(title: "Reset Password", message: "Enter your email address to reset your password.", preferredStyle: .alert)
        
        alertController.addTextField { (textField) in
            textField.placeholder = "Email"
            textField.keyboardType = .emailAddress
        }
        
        let resetAction = UIAlertAction(title: "Reset", style: .default) { (_) in
            if let email = alertController.textFields?.first?.text, !email.isEmpty {
                if self.isValidEmail(email) {
                    self.sendPasswordResetRequest(email: email)
                } else {
                    self.showAlert(message: "Please enter a valid email address.")
                }
            } else {
                self.showAlert(message: "Please enter your email address.")
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(resetAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func loginbtn(_ sender: Any) {
        if let emailText = email.text, let passwordText = pass.text {
            if emailText.isEmpty || passwordText.isEmpty {
                showAlert(message: "Please enter both email and password.")
            } else if !isValidEmail(emailText) {
                showAlert(message: "Please enter a valid email address.")
            } else if !isEmailRegistered(emailText, password: passwordText) {
                showAlert(message: "Invalid email or password.")
            } else {
                // Proceed to HomeViewController if login is successful
                let ms = UIStoryboard(name: "Main", bundle: nil)
                if let homeVC = ms.instantiateViewController(withIdentifier: "home") as? HomeViewController {
                    self.navigationController?.pushViewController(homeVC, animated: true)
                }
            }
        }
    }
    
    @IBAction func signupbtn(_ sender: Any) {
        let ms = UIStoryboard(name: "Main", bundle: nil)
        let nw = ms.instantiateViewController(withIdentifier: "signup") as! signupViewController
        self.navigationController?.pushViewController(nw, animated: true)
    }
    
    @IBAction func togglePasswordVisibility(_ sender: UIButton) {
        isPasswordVisible.toggle()
        pass.isSecureTextEntry = !isPasswordVisible
        updatePasswordVisibilityIcon()
    }
    
    private func updatePasswordVisibilityIcon() {
        let iconName = isPasswordVisible ? "showpass" : "hidepass"
        passimg.image = UIImage(named: iconName)
    }
    
    private func sendPasswordResetRequest(email: String) {
        print("Sending password reset request for email: \(email)")
        
        let alertController = UIAlertController(title: "Password Reset", message: "A password reset link has been sent to \(email).", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: email)
    }
    
    // Check if email is registered and password matches
    private func isEmailRegistered(_ email: String, password: String) -> Bool {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "email == %@ AND password == %@", email, password)
        
        do {
            let results = try context.fetch(fetchRequest)
            return !results.isEmpty
        } catch {
            print("Error checking email and password: \(error)")
            return false
        }
    }
    
    private func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    private func highlightLoginView() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = lgnvw.bounds
        lgnvw.layer.insertSublayer(gradientLayer, at: 0)
        
        lgnvw.layer.borderColor = UIColor.systemPurple.cgColor
        lgnvw.layer.borderWidth = 2.0
        lgnvw.layer.shadowColor = UIColor.black.cgColor
        lgnvw.layer.shadowOpacity = 0.6
        lgnvw.layer.shadowOffset = CGSize(width: 0, height: 4)
        lgnvw.layer.shadowRadius = 6.0
        
        view.bringSubviewToFront(lgnvw)
    }
    
    private func setupTextFieldStyles() {
        email.layer.cornerRadius = 5.0
        email.layer.borderWidth = 1.0
        email.layer.borderColor = UIColor.systemPurple.cgColor
        email.setLeftPaddingPoints(10)
        
        pass.layer.cornerRadius = 5.0
        pass.layer.borderWidth = 1.0
        pass.layer.borderColor = UIColor.systemPurple.cgColor
        pass.setLeftPaddingPoints(10)
    }
}
    
    extension UITextField {
        func setLeftPaddingPoints(_ amount: CGFloat) {
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.height))
            self.leftView = paddingView
            self.leftViewMode = .always
        }
    }

