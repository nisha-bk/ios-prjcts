import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var logovw: UIImageView!

    @IBOutlet weak var qplbe: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupGradientBackground()
        showAppLogo()
    }
    
    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        
        // Add the gradient layer to the view's layer
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    private func showAppLogo() {
        guard let logoImageView = logovw else { return }
        logoImageView.alpha = 0.0
        UIView.animate(withDuration: 1.0, animations: {
            logoImageView.alpha = 1.0
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.transitionToMainScreen()
        }
    }
    
    private func transitionToMainScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let loginVC = storyboard.instantiateViewController(withIdentifier: "login") as! loginViewController
        self.navigationController?.pushViewController(loginVC, animated: true)

//            if let window = UIApplication.shared.windows.first {
//                window.rootViewController = loginVC
//                window.makeKeyAndVisible()
//            }
        
    }
}
