import UIKit
import CoreData

class ProfileViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!

    // Assume we have a 'User' object or model that holds the user data
    var user: User?  // User object to hold the current user details

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up gradient background
        setupGradientBackground()

        self.navigationItem.title = "Profile"

        // Fetch user data from Core Data or another source
        fetchUserData()
    }

    // Fetch user data from persistent storage (e.g., Core Data)
    private func fetchUserData() {
        // For demonstration purposes, let's assume this is how you fetch the current user data
        // In your actual app, you should fetch data from Core Data, Firebase, or wherever it's stored

        // If you are using Core Data, fetch the user object from the persistent container
        if let currentUser = getCurrentUser() {
            user = currentUser
            nameLabel.text = currentUser.email
            emailLabel.text = currentUser.password
        } else {
            // If no user is found, handle appropriately (e.g., show an error or empty state)
            nameLabel.text = "No User"
            emailLabel.text = "No Email"
        }
    }

    // Fetch current user (from Core Data or other storage)
    private func getCurrentUser() -> User? {
        // This is a mock function. Replace with actual logic to fetch user from Core Data
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        do {
            let users = try context.fetch(fetchRequest)
            return users.first // Assuming only one user is stored
        } catch {
            print("Failed to fetch user: \(error)")
            return nil
        }
    }

    // Apply gradient background
    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    @IBAction func editProfileButtonTapped(_ sender: UIButton) {
        // Before navigating, pass the user object to the EditProfileViewController
        let ms = UIStoryboard(name: "Main", bundle: nil)
        if let editVC = ms.instantiateViewController(withIdentifier: "edit") as? EditProfileViewController {
            // Pass the current user data to the edit screen
            editVC.user = self.user
            self.navigationController?.pushViewController(editVC, animated: true)
        }
    }

}
