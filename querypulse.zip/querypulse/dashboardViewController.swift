import UIKit
import CoreData

class DashboardViewController: UIViewController {

    @IBOutlet weak var activeSurveysButton: UIButton!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var totalSurveysCompletedLabel: UILabel!
    @IBOutlet weak var completedSurveysButton: UIButton!
    @IBOutlet weak var recentActivityTableView: UITableView!

    var recentSurveys: [Survey] = []
    var totalSurveysCompleted: Int = 0
    var surveyCompletionProgress: Float = 0.75

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupGradientBackground()
        setupGradientForButton(activeSurveysButton)
        setupGradientForButton(completedSurveysButton)

        progressBar.progress = surveyCompletionProgress
        
        // Fetch surveys and update UI
        fetchSurveys()
    }

    private func setupUI() {
        self.navigationItem.hidesBackButton = true

        totalSurveysCompletedLabel.text = "Total Surveys Completed: \(totalSurveysCompleted)"
        totalSurveysCompletedLabel.font = UIFont.systemFont(ofSize: 16)
        totalSurveysCompletedLabel.textColor = .white
        totalSurveysCompletedLabel.textAlignment = .center

        recentActivityTableView.delegate = self
        recentActivityTableView.dataSource = self
        recentActivityTableView.reloadData()
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    private func setupGradientForButton(_ button: UIButton) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemBlue.cgColor, UIColor.systemGreen.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = button.bounds
        
        button.layer.cornerRadius = button.frame.height / 2
        button.clipsToBounds = true
        button.layer.insertSublayer(gradientLayer, at: 0)

        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 3)
        button.layer.shadowOpacity = 0.2
        button.layer.shadowRadius = 4.0
    }

    @IBAction func backbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func activeSurveysButtonTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let activeSurveysVC = storyboard.instantiateViewController(withIdentifier: "act") as? ActiveSurveysViewController {
            self.navigationController?.pushViewController(activeSurveysVC, animated: true)
        }
    }

    @IBAction func completedSurveysButtonTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let completedSurveysVC = storyboard.instantiateViewController(withIdentifier: "com") as? CompletedSurveysViewController {
            self.navigationController?.pushViewController(completedSurveysVC, animated: true)
        }
    }

    // MARK: - Core Data

    // Fetch surveys from Core Data
    private func fetchSurveys() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<Survey> = Survey.fetchRequest()

        do {
            let surveys = try context.fetch(fetchRequest)
            self.recentSurveys = surveys.filter { $0.isCompleted == true }.prefix(5).map { $0 }  // Filter recent completed surveys
            self.totalSurveysCompleted = surveys.filter { $0.isCompleted == true }.count

            totalSurveysCompletedLabel.text = "Total Surveys Completed: \(totalSurveysCompleted)"
            recentActivityTableView.reloadData()

        } catch {
            print("Error fetching surveys: \(error.localizedDescription)")
        }
    }
}

extension DashboardViewController: UITableViewDelegate, UITableViewDataSource {
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recentSurveys.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecentActivityCell", for: indexPath)
        let survey = recentSurveys[indexPath.row]
        cell.textLabel?.text = survey.title
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let survey = recentSurveys[indexPath.row]
        print("Selected survey: \(survey.title ?? "Unknown")")
    }
}

