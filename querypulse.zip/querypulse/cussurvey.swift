//
//  cussurvey.swift
//  querypulse
//
//  Created by Allnet Systems on 3/25/25.
//

import Foundation

class CustomSurvey {
    var title: String
    var description: String
    var questions: [String]

    init(title: String, description: String, questions: [String]) {
        self.title = title
        self.description = description
        self.questions = questions
    }
}

