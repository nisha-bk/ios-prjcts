//
//  resultsViewController.swift
//  querypulse
//
//  Created by Allnet Systems on 3/21/25.
//

import UIKit
import Charts

class ResultsViewController: UIViewController {
  
    @IBOutlet weak var resultsTextView: UITextView!
    @IBOutlet weak var resultGraphView: UIView!
    @IBOutlet weak var backButton: UIButton!
 
    var surveyResults = [
        "Survey Title": "Customer Satisfaction Survey",
        "Question 1": "How satisfied are you with the product?",
        "Response 1": "Very Satisfied",
        "Question 2": "Would you recommend our product?",
        "Response 2": "Yes",
        "Survey Completion": "Completed",
        "Survey Date": "March 21, 2025"
    ]

    var surveyStatistics: [String: Double] = [
        "Excellent": 50.0,
        "Good": 30.0,
        "Average": 10.0,
        "Poor": 10.0
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupGradientBackground()
        
        self.navigationItem.title = "Survey Results"
    
        displayResults()
        
        setupResultGraph()
    }

    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor, UIColor.systemTeal.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    private func displayResults() {
        var resultsText = ""
        
        for (key, value) in surveyResults {
            resultsText += "\(key): \(value)\n"
        }
        
        resultsTextView.text = resultsText
    }
    
    private func setupResultGraph() {
        let pieChartView = PieChartView(frame: CGRect(x: 20, y: 50, width: resultGraphView.frame.width - 40, height: 250))
        var entries = [ChartDataEntry]()
 
        for (category, percentage) in surveyStatistics {
            let entry = PieChartDataEntry(value: percentage, label: category)
            entries.append(entry)
        }
     
        let dataSet = PieChartDataSet(entries: entries, label: "Survey Responses")
        let data = PieChartData(dataSet: dataSet)
        pieChartView.data = data

        dataSet.colors = [UIColor.green, UIColor.blue, UIColor.orange, UIColor.red] 
        pieChartView.holeColor = UIColor.white
        pieChartView.legend.enabled = true
        pieChartView.centerText = "Survey Results"
        
        resultGraphView.addSubview(pieChartView)
    }

    @IBAction func backButtonTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
