// SurveyFormViewController.swift
import UIKit

class SurveyFormViewController: UIViewController {

    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answerTextField: UITextField!
    @IBOutlet weak var submitButton: UIButton!

    var survey: CustomSurvey?
    var currentQuestionIndex = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up gradient background
        setupGradientBackground()

        // Display the first question of the survey
        if let survey = survey {
            questionLabel.text = survey.questions[currentQuestionIndex]
        }

        // Apply gradient to the Submit button
        applyGradientToButton(submitButton)
    }

    // Apply gradient background to the view
    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    // Apply gradient to the button
    private func applyGradientToButton(_ button: UIButton) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemBlue.cgColor, UIColor.systemGreen.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = button.bounds
        button.layer.cornerRadius = button.frame.height / 2
        button.clipsToBounds = true
        button.layer.insertSublayer(gradientLayer, at: 0)
    }

    @IBAction func submitButtonTapped(_ sender: UIButton) {
        guard let answer = answerTextField.text, !answer.isEmpty else {
            showAlert(message: "Please provide an answer.")
            return
        }

        // Save or process the user's answer (e.g., add it to a database or send it to a server)
        print("Survey Answer Submitted: \(answer)")

        // Move to the next question or finish if it's the last question
        currentQuestionIndex += 1
        if currentQuestionIndex < survey?.questions.count ?? 0 {
            // Update the question and clear the answer text field
            questionLabel.text = survey?.questions[currentQuestionIndex]
            answerTextField.text = ""
        } else {
            // Survey completed
            showAlert(message: "Thank you for completing the survey!")
        }
    }

    private func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}
