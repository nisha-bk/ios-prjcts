//
//  Cat+CoreDataProperties.swift
//  
//
//  Created by Allnet Systems on 3/25/25.
//
//

import Foundation
import CoreData


extension Cat {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Cat> {
        return NSFetchRequest<Cat>(entityName: "Cat")
    }

    @NSManaged public var title: String?
    @NSManaged public var isSelected: Bool

}
