// SurveyDetailViewController.swift
import UIKit

class SurveyDetailViewController: UIViewController {

    @IBOutlet weak var startSurveyButton: UIButton!
    @IBOutlet weak var surveyTitleLabel: UILabel!
    @IBOutlet weak var surveyDescriptionLabel: UILabel!

    var survey: CustomSurvey?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up gradient background
        setupGradientBackground()

        // Set navigation title
        self.navigationItem.title = "Survey Details"
        
        // Display survey title and description
        if let survey = survey {
            surveyTitleLabel.text = survey.title
            surveyDescriptionLabel.text = survey.description
        }

        // Apply gradient to the Start Survey button
        applyGradientToButton(startSurveyButton)
    }

    // Apply gradient background to the view
    private func setupGradientBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemPurple.cgColor, UIColor.systemBlue.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    // Apply gradient to the button
    private func applyGradientToButton(_ button: UIButton) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.systemBlue.cgColor, UIColor.systemGreen.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = button.bounds
        button.layer.cornerRadius = button.frame.height / 2
        button.clipsToBounds = true
        button.layer.insertSublayer(gradientLayer, at: 0)
    }

    @IBAction func startSurveyButtonTapped(_ sender: UIButton) {
        // Navigate to Survey Form View Controller
        let ms = UIStoryboard(name: "Main", bundle: nil)
        if let surveyFormVC = ms.instantiateViewController(withIdentifier: "form") as? SurveyFormViewController {
            // Pass the survey data to the SurveyFormViewController
            surveyFormVC.survey = self.survey
            self.navigationController?.pushViewController(surveyFormVC, animated: true)
        }
    }
}
