//
//  Survey+CoreDataProperties.swift
//  
//
//  Created by Allnet Systems on 3/25/25.
//
//

import Foundation
import CoreData


extension Survey {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Survey> {
        return NSFetchRequest<Survey>(entityName: "Survey")
    }

    @NSManaged public var title: String?
    @NSManaged public var isCompleted: Bool
    @NSManaged public var dateCompleted: Date?

}
