//
//  ContentView.swift
//  todo
//
//  Created by Allnet Systems on 12/9/24.
//

import SwiftUI

// Model for a Todo item
struct TodoItem: Identifiable {
    var id = UUID()
    var title: String
    var description: String
}

struct ContentView: View {
    @State private var todos: [TodoItem] = [
        TodoItem(title: "Buy Groceries", description: "Milk, Eggs, Bread"),
        TodoItem(title: "Walk the Dog", description: "Take the dog to the park for a walk")
    ]
    
    @State private var showingAddTodoView = false
    
    var body: some View {
        NavigationView {
            VStack {
                List(todos) { todo in
                    NavigationLink(destination: TodoDetailView(todo: todo)) {
                        VStack(alignment: .leading) {
                            Text(todo.title)
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            Text(todo.description)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                    }
                    .padding([.top, .bottom], 5)
                }
                .navigationTitle("To-Do List")
                
                // Button to add new todo item
                Button(action: {
                    showingAddTodoView.toggle()
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .font(.title)
                        Text("Add New Todo")
                            .font(.title2)
                            .bold()
                    }
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                }
                .padding(.top, 20)
                .sheet(isPresented: $showingAddTodoView) {
                    AddTodoView(todos: $todos)
                }
            }
            .padding()
//            .background(Color.gray.edgesIgnoringSafeArea(.all))
        }
        
        
        
        
        
        
        
        
    }
}

// View for displaying details of a Todo item
struct TodoDetailView: View {
    var todo: TodoItem
    
    var body: some View {
        VStack {
            Text(todo.title)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top)
            
            Text(todo.description)
                .font(.body)
                .foregroundColor(.secondary)
                .padding([.top, .bottom])
            
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 10)
    }
}

// View for adding a new Todo item
struct AddTodoView: View {
    @Binding var todos: [TodoItem]
    
    @State private var title = ""
    @State private var description = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Todo Details").font(.headline)) {
                    TextField("Title", text: $title)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Description", text: $description)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                }
                
                Button("Save") {
                    let newTodo = TodoItem(title: title, description: description)
                    todos.append(newTodo)
                    title = ""
                    description = ""
                }
                .disabled(title.isEmpty || description.isEmpty)
                .padding()
                .background(title.isEmpty || description.isEmpty ? Color.gray : Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .navigationTitle("Add New Todo")
            .navigationBarItems(trailing: Button("Cancel") {
                title = ""
                description = ""
            })
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



