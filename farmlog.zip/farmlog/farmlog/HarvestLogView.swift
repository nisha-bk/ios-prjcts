import SwiftUI

struct HarvestLogView: View {
    @State private var harvests: [String] = [] {
        didSet {
            saveHarvests() // Save harvests when updated
        }
    }
    @State private var newHarvest: String = ""
    @State private var showingAddHarvestAlert = false
    
    // Load harvested items from UserDefaults
    init() {
        loadHarvests()
    }

    var body: some View {
        ZStack {
            // Gradient Background covering the entire screen
            LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.1), Color.yellow.opacity(0.1)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all) // Ensure the gradient covers the entire screen
            
            VStack {
                Text("🌾 Harvest Log")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundColor(.white) // Text color for title
                    .background(LinearGradient(gradient: Gradient(colors: [.green, .yellow]), startPoint: .leading, endPoint: .trailing)) // Gradient background for title
                    .cornerRadius(10)
                
                // Show empty state if no harvests exist
                if harvests.isEmpty {
                    Text("No harvests added yet.")
                        .font(.title3)
                        .foregroundColor(.gray)
                        .padding()
                }

                List {
                    ForEach(harvests, id: \.self) { harvest in
                        Text(harvest)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1))
                            .padding(.vertical, 5)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.3), Color.yellow.opacity(0.2)]), startPoint: .topLeading, endPoint: .bottomTrailing)) // Gradient background for each harvest item
                            .cornerRadius(10)
                    }
                    .onDelete(perform: deleteHarvest)
                }
                .padding()

                VStack(spacing: 20) {
                    TextField("Enter Harvest (e.g., Wheat - March)", text: $newHarvest)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                        .background(LinearGradient(gradient: Gradient(colors: [.green.opacity(0.2), .yellow.opacity(0.1)]), startPoint: .leading, endPoint: .trailing)) // Gradient background for TextField
                        .cornerRadius(12)
                    
                    Button(action: addHarvest) {
                        Text("Add Harvest")
                            .padding()
                            .background(LinearGradient(gradient: Gradient(colors: [.green, .yellow]), startPoint: .leading, endPoint: .trailing)) // Gradient for the button
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(radius: 10)
                    }
                    .padding(.top)
                    .disabled(newHarvest.isEmpty)
                }
                .padding(.top)
                .alert(isPresented: $showingAddHarvestAlert) {
                    Alert(title: Text("New Harvest Added"),
                          message: Text("You have successfully added the harvest."),
                          dismissButton: .default(Text("OK")))
                }
            }
            .padding() // Add padding inside the content to ensure it stays within screen bounds
        }
//        .navigationTitle("Harvest Log")
    }

    private func addHarvest() {
        if !newHarvest.isEmpty {
            harvests.append(newHarvest)
            newHarvest = "" // Clear the text field after adding
            showingAddHarvestAlert = true
        }
    }

    private func deleteHarvest(at offsets: IndexSet) {
        harvests.remove(atOffsets: offsets)
    }
    
    // MARK: - Persistence Methods
    private func saveHarvests() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(harvests) {
            UserDefaults.standard.set(encoded, forKey: "harvests")
        }
    }

    private func loadHarvests() {
        if let savedHarvests = UserDefaults.standard.data(forKey: "harvests") {
            let decoder = JSONDecoder()
            if let decodedHarvests = try? decoder.decode([String].self, from: savedHarvests) {
                harvests = decodedHarvests
            }
        }
    }
}
