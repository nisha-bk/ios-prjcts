import SwiftUI

struct InventoryView: View {
    @State private var inventoryItems: [InventoryItem] = []
    @State private var newItemName: String = ""
    @State private var newItemQuantity: String = ""
    @State private var newItemDescription: String = ""
    @State private var showingAlert = false

    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ScrollView {
            VStack {
                VStack(alignment: .center, spacing: 10) {
                    Text("📦Inventory Management")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(colorScheme == .dark ? .green : .green)

                    Text("Track and manage your farm's inventory")
                        .foregroundColor(colorScheme == .dark ? .gray : .black)
                        .font(.body)
                }
                .padding(.top, 100)
                .padding(.horizontal)

                LazyVStack {
                    ForEach(inventoryItems) { item in
                        HStack {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.name)
                                    .font(.headline)
                                    .foregroundColor(colorScheme == .dark ? .white : .primary)

                                Text("Qty: \(item.quantity)")
                                    .font(.subheadline)
                                    .foregroundColor(colorScheme == .dark ? .white : .gray)

                                Text(item.description)
                                    .font(.body)
                                    .foregroundColor(colorScheme == .dark ? .white : .gray)
                                    .lineLimit(2)
                            }
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray, lineWidth: 1)
                                .background(Color.white)
                                .shadow(radius: 5))
                        }
                    }
                    .onDelete(perform: deleteItem)
                }
                .padding(.horizontal)

                VStack(spacing: 15) {
                    TextField("Item Name", text: $newItemName)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)

                    TextField("Quantity", text: $newItemQuantity)
                        .padding()
                        .keyboardType(.numberPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                        .onChange(of: newItemQuantity) { newValue in
                            if let _ = Int(newValue) {
                            } 
                            else {
                                newItemQuantity = String(newValue.dropLast())
                            }
                        }

                    TextField("Description", text: $newItemDescription)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)

                    Button(action: addItem) {
                        Text("Add Item")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(12)
                            .shadow(radius: 10)
                    }
                    .padding(.top, 10)
                    .disabled(newItemName.isEmpty || newItemQuantity.isEmpty || newItemDescription.isEmpty || Int(newItemQuantity) == nil || Int(newItemQuantity)! <= 0)
                }
                .padding(.top, 20)
                .padding(.horizontal)
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Item Added"),
                          message: Text("The item has been added to your inventory."),
                          dismissButton: .default(Text("OK")))
                }
                Spacer()
            }
        }
        .background(LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.2), Color.blue.opacity(0.2)]), startPoint: .topLeading, endPoint: .bottomTrailing))
        .edgesIgnoringSafeArea(.all)
    }

    private func addItem() {
        guard let quantity = Int(newItemQuantity), quantity > 0 else { return }
        let newItem = InventoryItem(name: newItemName, quantity: quantity, description: newItemDescription)
        inventoryItems.append(newItem)
        newItemName = ""
        newItemQuantity = ""
        newItemDescription = ""
        showingAlert = true
    }

    private func deleteItem(at offsets: IndexSet) {
        inventoryItems.remove(atOffsets: offsets)
    }
}

struct InventoryItem: Identifiable {
    let id = UUID()
    let name: String
    let quantity: Int
    let description: String
}
