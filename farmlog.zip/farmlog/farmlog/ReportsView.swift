import SwiftUI
import Charts // Ensure that you have Charts framework imported

struct ReportsView: View {
    // Dynamic data
    @State private var expenses: Double = 0
    @State private var cropsYielded: Double = 0
    @State private var weatherPattern: String = "Loading..."
    
    // Sample dynamic data for charts (replace with actual data later)
    @State private var expenseData: [Double] = []
    @State private var yieldData: [Double] = []
    
    // Error handling
    @State private var isLoading = true
    @State private var errorMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Title Section
                Text("📊 Reports & Insights")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color("PrimaryGreen")) // Custom color
                    .padding(.top)

                // Report Summary Section
                VStack(alignment: .leading, spacing: 16) {
                    if isLoading {
                        ProgressView("Loading...")
                            .progressViewStyle(CircularProgressViewStyle())
                            .padding()
                    } else if let errorMessage = errorMessage {
                        Text("Error: \(errorMessage)")
                            .foregroundColor(.red)
                            .padding()
                    } else {
                        Text("Expenses: $\(expenses, specifier: "%.2f")")
                            .font(.title2)
                            .foregroundColor(Color("ExpenseColor"))
                        
                        Text("Crops Yielded: \(cropsYielded, specifier: "%.0f") bushels")
                            .font(.title2)
                            .foregroundColor(Color("YieldColor"))
                        
                        Text("Weather Pattern: \(weatherPattern)")
                            .font(.title2)
                            .foregroundColor(.gray)
                    }
                }
                .padding(.horizontal)

                Divider()

                // Charts Section
                VStack(alignment: .leading, spacing: 24) {
                    // Expense Trend Section
                    Text("🛠️ Expense Trend")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color("ExpenseColor"))

                    // Expense Trend Chart
                    Chart {
                        ForEach(expenseData.indices, id: \.self) { index in
                            LineMark(
                                x: .value("Month \(index + 1)", index),
                                y: .value("Expenses", expenseData[index])
                            )
                            .foregroundStyle(Color("ExpenseColor"))
                            .lineStyle(StrokeStyle(lineWidth: 3, dash: [5, 3])) // Dotted line style
                        }
                    }
                    .frame(height: 250)
                    .background(LinearGradient(gradient: Gradient(colors: [Color("ExpenseColor").opacity(0.2), Color.blue.opacity(0.1)]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .cornerRadius(15)
                    .shadow(radius: 5)

                    // Crop Yield Trend Section
                    Text("🌾 Crop Yield Trend")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color("YieldColor"))

                    // Crop Yield Trend Chart
                    Chart {
                        ForEach(yieldData.indices, id: \.self) { index in
                            LineMark(
                                x: .value("Month \(index + 1)", index),
                                y: .value("Yield", yieldData[index])
                            )
                            .foregroundStyle(Color("YieldColor"))
                            .lineStyle(StrokeStyle(lineWidth: 3)) // Solid line style
                        }
                    }
                    .frame(height: 250)
                    .background(LinearGradient(gradient: Gradient(colors: [Color("YieldColor").opacity(0.2), Color.green.opacity(0.1)]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .cornerRadius(15)
                    .shadow(radius: 5)
                }

                // Detailed Insights Section
                VStack(alignment: .leading, spacing: 20) {
                    Text("🌤️ Detailed Insights")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)

                    Text("The weather over the past month has been primarily sunny, contributing to the healthy crop yield.")
                        .font(.body)
                        .foregroundColor(.black)

                    Text("Expenses have been steadily increasing, likely due to the rising costs of equipment and labor.")
                        .font(.body)
                        .foregroundColor(.black)
                }
                .padding(.horizontal)
            }
            .padding(.horizontal)
            .padding(.bottom, 24)
            .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.2), Color.purple.opacity(0.2)]), startPoint: .topLeading, endPoint: .bottomTrailing)) // Gradient background for the whole view
            .cornerRadius(20)
            .shadow(radius: 10)
        }
        .onAppear {
            fetchDynamicData()
        }
    }

    // Simulated data fetching function
    func fetchDynamicData() {
        // Simulating a delay like an API call
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            // Simulate dynamic data
            self.expenses = 1200
            self.cropsYielded = 1800
            self.weatherPattern = "Mostly Cloudy"
            self.expenseData = [300, 500, 400, 600, 700]
            self.yieldData = [350, 600, 450, 700, 800]
            self.isLoading = false
        }
    }
}
