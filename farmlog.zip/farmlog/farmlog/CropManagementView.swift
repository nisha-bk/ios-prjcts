import SwiftUI

struct CropManagementView: View {
    @State private var crops = ["Wheat", "Corn", "Rice", "Barley"]
    
    @Environment(\.colorScheme) var colorScheme // For dynamic light/dark mode handling

    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .center, spacing: 10) {
                    Text("Crop Management")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(colorScheme == .dark ? .green : Color.green)
                    
                    Text("Track the growth of your crops.")
                        .foregroundColor(colorScheme == .dark ? .gray : .black)
                        .font(.body)
                }
                .padding(.top, 20)
                .padding(.horizontal)
   
                ScrollView {
                    VStack {
                        ForEach(crops, id: \.self) { crop in
                            HStack {
                                Text(crop)
                                    .font(.title3)
                                    .fontWeight(.medium)
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                                    .padding()
                                
                                Spacer()
                            }
                            .background(LinearGradient(gradient: Gradient(colors: [
                                colorScheme == .dark ? Color.green.opacity(0.3) : Color.green.opacity(0.1),
                                colorScheme == .dark ? Color.blue.opacity(0.3) : Color.blue.opacity(0.1)
                            ]), startPoint: .topLeading, endPoint: .bottomTrailing))
                            .cornerRadius(12)
                            .shadow(radius: 5)
                            .padding(.horizontal)
                        }
                    }
                    .padding(.top, 20)
     
                    NavigationLink(destination: AddFarmLogView()) {
                        Text("➕ Add New Crop")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(LinearGradient(gradient: Gradient(colors: [
                                colorScheme == .dark ? Color.green : Color.green,
                                colorScheme == .dark ? Color.blue : Color.blue
                            ]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(12)
                            .shadow(radius: 10)
                            .padding(.horizontal)
                    }
                    .padding(.top, 20)
                }
                .background(LinearGradient(gradient: Gradient(colors: [
                    colorScheme == .dark ? Color.green.opacity(0.3) : Color.green.opacity(0.2),
                    colorScheme == .dark ? Color.blue.opacity(0.3) : Color.blue.opacity(0.2)
                ]), startPoint: .topLeading, endPoint: .bottomTrailing))
                .edgesIgnoringSafeArea(.bottom)
            }
            .navigationBarHidden(true)
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

