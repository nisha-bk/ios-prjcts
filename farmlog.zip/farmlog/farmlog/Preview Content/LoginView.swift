import SwiftUI

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isLoggedIn = false

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]),
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()

                VStack {
                    Spacer()

                    VStack(spacing: 10) {
                        Image(systemName: "leaf.fill")
                            .resizable()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.white)
                            .shadow(radius: 5)

                        Text("FarmLog")
                            .font(.system(size: 34, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .padding(.bottom, 30)

                    VStack(spacing: 20) {
                        CustomTf(placeholder: "Email", text: $email, isSecure: false)
                        CustomTf(placeholder: "Password", text: $password, isSecure: true)

                        Button(action: {
                            login()
                        }) {
                            Text("Log In")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]),
                                                   startPoint: .leading, endPoint: .trailing)
                                )
                                .cornerRadius(12)
                                .shadow(radius: 4)
                        }

                        NavigationLink("Don't have an account? Sign Up", destination: SignupView())
                            .font(.footnote)
                            .foregroundColor(.white.opacity(0.8))
                            .underline()
                    }
                    .padding(25)
                    .background(.ultraThinMaterial)
                    .cornerRadius(20)
                    .padding(.horizontal, 30)
                    .shadow(radius: 10)

                    Spacer()
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text(isLoggedIn ? "Login Successful" : "Message"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK")) {
                        if isLoggedIn {
                            isLoggedIn = true
                        }
                    }
                )
            }
            .fullScreenCover(isPresented: $isLoggedIn) {
                DashboardView()
            }
        }
    }

    // Function to validate login credentials
    func login() {
        if email.isEmpty || password.isEmpty {
            alertMessage = "Please enter both email and password."
            showAlert = true
            return
        }

        if CoreDataManager.shared.validateUser(email: email, password: password) {
            alertMessage = "Logged in successfully!"
            isLoggedIn = true
        } else {
            alertMessage = "Invalid email or password."
            showAlert = true
        }
    }
}


struct CustomTf: View {
    var placeholder: String
    @Binding var text: String
    var isSecure: Bool

    var body: some View {
        Group {
            if isSecure {
                SecureField(placeholder, text: $text)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.white, lineWidth: 2).background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.2))))
                    .foregroundColor(.white)
            } else {
                TextField(placeholder, text: $text)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.white, lineWidth: 2).background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.2))))
                    .foregroundColor(.white)
            }
        }
        .padding(.horizontal, 15)
        .frame(maxWidth: .infinity)
    }
}

