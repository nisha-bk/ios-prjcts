import SwiftUI

struct Event: Identifiable, Codable {
    let id = UUID()
    var date: Date
    var title: String
}

struct FarmersCalendarView: View {
    @State private var events: [Event] = [] {
        didSet {
            saveEvents()
        }
    }
    
    @State private var newEventDate = Date()
    @State private var newEventTitle = ""
    
    var body: some View {
        VStack {
            Text("📅 Farmer's Calendar")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.white)
                .background(LinearGradient(gradient: Gradient(colors: [.green, .yellow]), startPoint: .leading, endPoint: .trailing))
                .padding(.top)

            List {
                ForEach(events.sorted { $0.date < $1.date }) { event in
                    HStack {
                        Text(event.date, style: .date)
                            .fontWeight(.semibold)
                            .padding(.trailing)

                        Text(event.title)
                            .font(.body)
                    }
                }
                .onDelete(perform: deleteEvent)
            }
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.7), Color.white.opacity(0.2)]), startPoint: .top, endPoint: .bottom)) 

            // Add New Event Section
            VStack {
                TextField("Event Title", text: $newEventTitle)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                DatePicker("Select Date", selection: $newEventDate, displayedComponents: [.date])
                    .padding()

                Button(action: addEvent) {
                    Text("Add Event")
                        .padding()
                        .background(
                            LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .leading, endPoint: .trailing)
                        )
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.top)
            }
            .padding(.top)
        }
//        .navigationTitle("Farmer's Calendar")
        .background(
            LinearGradient(gradient: Gradient(colors: [Color("BackgroundColor1"), Color("BackgroundColor2")]), startPoint: .top, endPoint: .bottom)
        )
        .onAppear(perform: loadEvents) // Load events when the view appears
    }
    
    // Add Event
    private func addEvent() {
        if !newEventTitle.isEmpty {
            let newEvent = Event(date: newEventDate, title: newEventTitle)
            events.append(newEvent)
            newEventTitle = "" // Clear the text field after adding
        }
    }

    // Delete Event
    private func deleteEvent(at offsets: IndexSet) {
        events.remove(atOffsets: offsets)
    }

    // MARK: - Persistence Methods
    private func saveEvents() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(events) {
            UserDefaults.standard.set(encoded, forKey: "events")
        }
    }

    private func loadEvents() {
        if let savedEvents = UserDefaults.standard.data(forKey: "events") {
            let decoder = JSONDecoder()
            if let decodedEvents = try? decoder.decode([Event].self, from: savedEvents) {
                events = decodedEvents
            }
        }
    }
}
