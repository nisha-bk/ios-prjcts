import SwiftUI

struct FarmLogsListView: View {
    @FetchRequest(entity: FarmLog.entity(), sortDescriptors: []) var farmLogs: FetchedResults<FarmLog>
    @Environment(\.managedObjectContext) private var viewContext

    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [
                colorScheme == .dark ? Color.green.opacity(0.3) : Color.green.opacity(0.2),
                colorScheme == .dark ? Color.blue.opacity(0.3) : Color.blue.opacity(0.2)
            ]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack {
                if farmLogs.isEmpty {
                    // Placeholder for no logs
                    VStack {
                        Image(systemName: "leaf.arrow.circlepath")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(colorScheme == .dark ? Color.green : Color.green.opacity(0.7))

                        Text("No logs yet! Start adding 🌱")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .padding()
                    }
                } else {
                    List {
                        ForEach(farmLogs, id: \.self) { log in
                            HStack(spacing: 15) {
                                Image(systemName: "leaf.fill")
                                    .foregroundColor(.green)
                                    .font(.title)

                                VStack(alignment: .leading) {
                                    Text("\(log.crop ?? "Unknown")")
                                        .font(.headline)
                                        .foregroundColor(colorScheme == .dark ? .white : .black)

                                    Text("\(log.activity ?? "No Activity")")
                                        .font(.subheadline)
                                        .foregroundColor(colorScheme == .dark ? .gray : .secondary)

                                    Text("\(log.date ?? Date(), formatter: dateFormatter)")
                                        .font(.caption)
                                        .foregroundColor(colorScheme == .dark ? .white : .gray)
                                }
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(colorScheme == .dark ? Color.black.opacity(0.3) : Color.white)
                                    .shadow(radius: 5)
                            )
                        }
                        .onDelete(perform: deleteLog)
                    }
                    .scrollContentBackground(.hidden)
                    .background(Color.clear)
                }
            }
        }
        .navigationTitle("🌾 Farm Logs")
        .toolbar {
            EditButton()
                .foregroundColor(colorScheme == .dark ? .red : .blue)
        }
    }

    private func deleteLog(at offsets: IndexSet) {
        for index in offsets {
            viewContext.delete(farmLogs[index])
        }
        try? viewContext.save()
    }
}

private let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    return formatter
}()
