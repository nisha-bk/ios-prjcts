//
//  Expense+CoreDataClass.swift
//  farmlog
//
//  Created by Allnet Systems on 4/30/25.
//
//

import Foundation
import CoreData

@objc(Expense)
public class Expense: NSManagedObject {

}
